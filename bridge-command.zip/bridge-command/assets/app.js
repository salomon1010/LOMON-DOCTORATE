/* BRIDGE COMMAND — shared app logic (localStorage; fine on GitHub Pages) */
const BC = {
  KEY: 'bridge-command-v1',
  COURSES: [
    {id:'stats',   code:'MATH 2350',  name:'Statistics',              page:'stats.html',            zy:'$64'},
    {id:'linalg',  code:'MATH 2330',  name:'Linear Algebra',          page:'linear-algebra.html',   zy:'$64'},
    {id:'calc',    code:'MATH 2340',  name:'Calculus',                page:'calculus.html',         zy:'~$69'},
    {id:'prog',    code:'CMPSC 2310', name:'Foundations of Programming', page:'programming.html',   zy:'$99'},
    {id:'dsa',     code:'CMPSC 2320', name:'Data Structures & Algorithms', page:'dsa.html',         zy:'~$99'},
  ],
  state: null,

  load(){
    try { this.state = JSON.parse(localStorage.getItem(this.KEY)) || {}; }
    catch(e){ this.state = {}; }
    this.state.modules  = this.state.modules  || {};   // 'stats-1' -> {content:bool, score:num|null, hours:num, date:str}
    this.state.papers   = this.state.papers   || [];
    this.state.gap      = this.state.gap      || {};
    this.state.sessions = this.state.sessions || [];   // {date, mins, track}
    this.state.enrolled = this.state.enrolled || {};   // courseId -> bool (PSU said required)
    return this.state;
  },
  save(){ localStorage.setItem(this.KEY, JSON.stringify(this.state)); this.toast('Saved'); },

  mod(id){ return this.state.modules[id] || (this.state.modules[id] = {content:false, score:null, hours:0, date:''}); },
  passed(id){ const m = this.state.modules[id]; return !!(m && m.score !== null && m.score >= 80); },
  attempted(id){ const m = this.state.modules[id]; return !!(m && (m.content || m.score !== null || m.hours > 0)); },

  courseProgress(cid){
    let p = 0; for (let i = 1; i <= 5; i++) if (this.passed(cid + '-' + i)) p++;
    return p; // of 5
  },
  totalPassed(){ let t = 0; this.COURSES.forEach(c => t += this.courseProgress(c.id)); return t; },
  totalHours(){
    let h = 0; Object.values(this.state.modules).forEach(m => h += (+m.hours || 0));
    return Math.round(h * 10) / 10;
  },

  logSession(mins, track){
    const today = new Date().toISOString().slice(0, 10);
    this.state.sessions.push({date: today, mins: +mins, track});
    this.save();
  },
  streak(){
    const days = new Set(this.state.sessions.map(s => s.date));
    let n = 0; const d = new Date();
    // today counts if present; otherwise start from yesterday
    if (!days.has(d.toISOString().slice(0,10))) d.setDate(d.getDate() - 1);
    while (days.has(d.toISOString().slice(0,10))) { n++; d.setDate(d.getDate() - 1); }
    return n;
  },
  researchHours(){
    let m = 0; this.state.sessions.forEach(s => { if (s.track === 'research') m += s.mins; });
    return Math.round(m / 6) / 10;
  },

  /* ---------- UI helpers ---------- */
  toast(msg){
    let t = document.querySelector('.toast');
    if (!t) { t = document.createElement('div'); t.className = 'toast'; document.body.appendChild(t); }
    t.textContent = msg; t.classList.add('show');
    clearTimeout(this._tt); this._tt = setTimeout(() => t.classList.remove('show'), 1800);
  },

  railProgress(){
    this.COURSES.forEach(c => {
      const a = document.querySelector(`[data-nav="${c.id}"] .pct`);
      if (a) { const p = this.courseProgress(c.id); a.textContent = p + '/5';
        if (p === 5) a.closest('a').classList.add('done'); }
    });
  },

  gateGrid(el){
    el.innerHTML = '';
    this.COURSES.forEach(c => {
      for (let i = 1; i <= 5; i++) {
        const id = c.id + '-' + i, g = document.createElement('a');
        g.className = 'gate'; g.href = c.page + '#m' + i;
        if (this.passed(id)) g.classList.add('pass');
        else if (this.attempted(id)) g.classList.add('wip');
        const m = this.state.modules[id];
        g.innerHTML = `<span class="g-course">${c.code}</span>
          <span class="g-mod">${(BC.MODNAMES[c.id] || [])[i-1] || 'Module ' + i}</span>
          <span class="g-score">${m && m.score !== null ? m.score + '%' : '· gate: 80%'}</span>`;
        el.appendChild(g);
      }
    });
  },

  /* module names for gate grid labels */
  MODNAMES: {
    stats:  ['Descriptive & Probability','Distributions','CI & Hypothesis Tests','Regression','Chi-Square'],
    linalg: ['Vectors & Matrices','Systems of Equations','Transformations','Eigen-analysis','Applications'],
    calc:   ['Functions & Limits','Derivatives','Derivative Applications','Integrals','Optimization'],
    prog:   ['Python Basics','Control Flow','Functions & Modules','Classes & Files','Program Design'],
    dsa:    ['Lists & Dicts','Stacks & Queues','Sorting','Searching & Big-O','Choosing Structures'],
  },

  /* ---------- module card renderer (course pages) ---------- */
  renderModules(cid, moduleData, mount){
    moduleData.forEach((md, ix) => {
      const i = ix + 1, id = cid + '-' + i, m = this.mod(id);
      const sec = document.createElement('section');
      sec.className = 'module'; sec.id = 'm' + i;
      const st = this.passed(id) ? '<span class="badge pass">GATE PASSED</span>'
        : (m.score !== null ? '<span class="badge gatefail">BELOW 80% — RETAKE</span>'
        : '<span class="badge">GATE: 80%</span>');
      sec.innerHTML = `
        <header><span class="mnum">MODULE ${i}</span><h3>${md.title}</h3>${st}</header>
        <div class="body">
          <div class="topics">${md.topics.map(t => '<span>' + t + '</span>').join('')}</div>
          <label class="checkline"><input type="checkbox" data-content="${id}" ${m.content ? 'checked' : ''}>
            zyBook content + participation activities complete</label>
          <div class="mrow">
            <div><label>PSU quiz score (%)</label>
              <input type="number" min="0" max="100" data-score="${id}" value="${m.score ?? ''}" placeholder="—"></div>
            <div><label>Hours logged</label>
              <input type="number" min="0" step="0.5" data-hours="${id}" value="${m.hours || ''}" placeholder="0"></div>
            <div><button data-savemod="${id}">Save module</button></div>
          </div>
          <div class="practice">
            <div class="ptitle">Participation activities — answer before checking</div>
            <div data-practice="${id}"></div>
          </div>
        </div>`;
      mount.appendChild(sec);
      const pm = sec.querySelector('[data-practice="' + id + '"]');
      (md.questions || []).forEach(q => pm.appendChild(this.question(q)));
    });

    mount.addEventListener('click', e => {
      const b = e.target.closest('[data-savemod]');
      if (!b) return;
      const id = b.dataset.savemod, m = this.mod(id);
      m.content = mount.querySelector(`[data-content="${id}"]`).checked;
      const sv = mount.querySelector(`[data-score="${id}"]`).value;
      m.score = sv === '' ? null : Math.max(0, Math.min(100, +sv));
      m.hours = +mount.querySelector(`[data-hours="${id}"]`).value || 0;
      m.date = new Date().toISOString().slice(0, 10);
      this.save();
      if (m.hours > 0) this.logSession(m.hours * 60, 'bridge');
      location.reload();
    });
  },

  /* zyBook-style question: instant feedback + explanation */
  question(q){
    const d = document.createElement('div');
    d.className = 'q';
    d.innerHTML = `<div class="tag">${q.tag || 'concept check'}</div>
      <div class="qtext">${q.q}</div><div class="opts"></div>
      <div class="expl"><strong>${'Why:'}</strong> ${q.why}</div>`;
    const opts = d.querySelector('.opts');
    q.opts.forEach((o, i) => {
      const b = document.createElement('button');
      b.textContent = o;
      b.addEventListener('click', () => {
        if (d.classList.contains('answered')) return;
        d.classList.add('answered');
        if (i === q.a) b.classList.add('correct');
        else { b.classList.add('wrong'); opts.children[q.a].classList.add('correct'); }
      });
      opts.appendChild(b);
    });
    return d;
  },

  /* ---------- export / import ---------- */
  exportJSON(){
    const blob = new Blob([JSON.stringify(this.state, null, 2)], {type: 'application/json'});
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'bridge-command-backup-' + new Date().toISOString().slice(0,10) + '.json';
    a.click();
  },
  importJSON(file){
    const r = new FileReader();
    r.onload = () => {
      try { this.state = JSON.parse(r.result); this.save(); location.reload(); }
      catch(e){ this.toast('Invalid backup file'); }
    };
    r.readAsText(file);
  },

  initRail(active){
    const rail = document.querySelector('.rail');
    rail.innerHTML = `
      <div class="brand">Bridge Command<small>Lomon Academy · D.Eng. Track</small></div>
      <nav>
        <a href="index.html" data-nav="home" class="${active==='home'?'active':''}">Dashboard</a>
        <div class="grp">Bridge Courses</div>
        ${this.COURSES.map(c => `<a href="${c.page}" data-nav="${c.id}" class="${active===c.id?'active':''}">
          ${c.name}<span class="pct">0/5</span></a>`).join('')}
        <div class="grp">Doctorate Repair</div>
        <a href="research.html" data-nav="research" class="${active==='research'?'active':''}">Research Track</a>
      </nav>
      <div class="foot">
        Data lives in this browser.
        <button class="ghost" onclick="BC.exportJSON()">Export backup</button>
        <button class="ghost" onclick="document.getElementById('bc-imp').click()">Import backup</button>
        <input id="bc-imp" type="file" accept=".json" style="display:none"
          onchange="BC.importJSON(this.files[0])">
      </div>`;
    this.railProgress();
  }
};
BC.load();
